// #define VT_XP_TEXT 0x<hex rgb>
