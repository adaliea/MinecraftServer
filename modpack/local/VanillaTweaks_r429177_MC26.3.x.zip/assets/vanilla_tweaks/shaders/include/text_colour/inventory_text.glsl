// #define VT_INVENTORY_UI_COLOUR 0x<hex rgb>
